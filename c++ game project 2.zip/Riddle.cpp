#include "Riddle.h"
#include "utils.h"
#include <conio.h>
#include <iostream>

bool Riddle::ask() {
  cls();
  // 01234567890123456789012345678901234567890123456789012345678901234567890123456789//
  std::cout << "==================================== Riddle "
               "====================================\n"
            << std::endl;
  // Display the riddle question and possible answers
  std::cout << question << "\n\n";
  for (int i = 0; i < 4; ++i) {
    std::cout << "   " << (i + 1) << " - " << lines[i] << "\n";
  }
  std::cout << "==============================================================="
               "=================\n";

  int choice = 0;
  while (true) {
    // std::cout << "Choose your answer (1-4): " << std::flush;
    char c = _getch();
    if (c >= '1' && c <= '4') {
      choice = c - '1';
      break;
    }
  }
  return (choice == correctIndex);
}
