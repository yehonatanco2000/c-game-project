﻿#include "game.h"
#include "Directions.h"
#include "Menu.h"
#include "Riddle.h"
#include "Screen.h"
#include "player.h"
#include <Windows.h>
#include <algorithm>
#include <conio.h>
#include <fstream> 
#include <iostream>
#include <queue>
#include <string>

void game::start_game() {
  if (!loadSuccess) {
    cls();
    std::cout << "==========================================================="
              << std::endl;
    std::cout << fatalError << std::endl;
    std::cout << "==========================================================="
              << std::endl;
    std::cout << "\nPress any key to return to menu..." << std::endl;
    _getch();
    cls();
    Menu return_menu;
    return_menu.show_menu();
    return;
  }

  hideCursor();            // Hide console cursor during the game
  constexpr char ESC = 27; // ESC key code
  theScreen.draw();        // Initial draw of the whole screen
  drawHUD();
  p1.updateHUD();
  p2.updateHUD();

  // Store previous positions to detect movement
  int lastP1X = p1.getX(), lastP1Y = p1.getY();
  int lastP2X = p2.getX(), lastP2Y = p2.getY();

  // Track if players held a torch in the previous frame
  bool lastP1HadTorch = (p1.getCarryItem() == '!');
  bool lastP2HadTorch = (p2.getCarryItem() == '!');
  int timer = 0;
  int width = 62;
  while (true) {

    theScreen.setTorchInfo(p1.getCarryItem() == '!', // player 1 holds torch?
                           p2.getCarryItem() == '!', // player 2 holds torch?
                           p1.getX(), p1.getY(), p2.getX(), p2.getY());

    // Optimization: Only redraw full screen if lighting conditions change
    bool needRedraw = false;

    // 1. Check if players moved (while holding torch)
    bool p1Moved = (p1.getX() != lastP1X || p1.getY() != lastP1Y);
    bool p2Moved = (p2.getX() != lastP2X || p2.getY() != lastP2Y);
    bool p1HasTorch = (p1.getCarryItem() == '!');
    bool p2HasTorch = (p2.getCarryItem() == '!');

    if ((p1Moved && p1HasTorch) || (p2Moved && p2HasTorch)) {
      needRedraw = true;
    }

    // 2. Check if torch status CHANGED (Pickup or Drop)
    if (p1HasTorch != lastP1HadTorch || p2HasTorch != lastP2HadTorch) {
      needRedraw = true;
    }

    // Update trackers for next frame
    lastP1X = p1.getX();
    lastP1Y = p1.getY();
    lastP2X = p2.getX();
    lastP2Y = p2.getY();
    lastP1HadTorch = p1HasTorch;
    lastP2HadTorch = p2HasTorch;

    if (needRedraw) {
      theScreen.draw();
      drawHUD();
    }

    timer++;
    if (timer % GAME_CLOCK_TICKS_PER_SECOND == 0) {
        setTimeGame(getTimeGame() + 1); // game time++
        if (getScore() >= 100)
            width = 63;
        int tx = getHudX() + width;
        int ty = getHudY() + 2;
        if (currentRoom != 3 && (!p1HasTorch && !p2HasTorch)) {
            gotoxy(tx, ty);
            std::cout << (TIME_PER_GAME - getTimeGame()) << std::flush;
        }
    }

    // HUD should be updated if needed, but its functions handle cursor
    // positioning well drawHUD(); // Static parts of HUD rarely change
    if (p1.getIsActive())
      p1.updateHUD();
    if (p2.getIsActive())
      p2.updateHUD();

    for (auto &b : bombs) { // Update all active bombs
      if (!b.alive)
        continue;                         // Skip bombs that already exploded
      gotoxy(b.x, b.y);                   // Move cursor to bomb position
      std::cout << b.timer << std::flush; // Show remaining timer
      Sleep(50);                          // Small delay for visual effect
      if (--b.timer == 0) {               // Decrease timer and check explosion
        explodeAt(b.x, b.y);              // Trigger explosion effect
        b.alive = false;                  // Mark bomb as dead
        // Explosion changes the board, but explodeAt handles local redraw.
        // If explosion changes enough to warrant full redraw (e.g. destroys
        // many walls), we could set needRedraw=true for next frame, but
        // explodeAt does its job.
        theScreen.draw();
        drawHUD();
      }
    }

    if (p1.getIsActive()) {
      p1.move(); // Move player 1 if still active
    }

    if (p2.getIsActive()) {
      p2.move(); // Move player 2 if still active
    }

    Sleep(100); // Control game speed

    if (_kbhit()) {        // Check if any key was pressed
      char key = _getch(); // Read key

      if ((unsigned char)key == 224 || (unsigned char)key == 0) {
        // Special key (arrows / function keys) - consume extra byte and ignore
        _getch();
        // Do not call keyPressed for arrow keys
      }

      if (key == ESC) { // Pause menu when ESC is pressed
        int action = pause_menu();
        if (action == 1) { // Return to main menu
          cls();
          Menu show_main_menu;
          show_main_menu.show_menu();
          break; // Exit game loop
        } else { // Continue game
          theScreen.draw();
          drawHUD();
          p1.updateHUD();
          p2.updateHUD();
          // Reset movement trackers to avoid immediate redraw if not needed
          lastP1X = p1.getX();
          lastP1Y = p1.getY();
          lastP2X = p2.getX();
          lastP2Y = p2.getY();
        }
      } else {
        p1.keyPressed(key); // Send key to player 1
        p2.keyPressed(key); // Send key to player 2
      }
    }
  }

  return; // End of start_game
}

void game::initObjectsFromBoard() {
  riddles.clear(); // Remove old riddles from previous room

  for (int y = 0; y <= Screen::MAX_Y; ++y) {
    for (int x = 0; x <= Screen::MAX_X; ++x) {
      char ch = theScreen.board[y][x]; // Character at current board cell

      if (ch == 'k') {
        keys.emplace_back(x, y); // Add key object at this position
      }
      if (ch == '?') {
        if (!all_riddles.empty()) {
          int idx = nextRiddleIndex % all_riddles.size();
          riddles.emplace_back(x, y, all_riddles[idx]);
          ++nextRiddleIndex;
        }
      } else if (ch == '/' || ch == '\\') { // Found a switch
        switchOn = (ch == '/');             // '/' means ON
        if (currentRoom == 1 || currentRoom == 2) {
          switches.emplace_back(x, y, switchOn,
                                SwitchType::DOOR); // Switch controls door
        } else {
          switches.emplace_back(x, y, switchOn,
                                SwitchType::WALL); // Switch controls wall
        }
      } else if (ch == '@') {
        bombItem.emplace_back(x, y); // Bomb item on floor
      } else if (ch >= '1' && ch <= '9') {
        doors.emplace_back(x, y, ch); // Door with required keys
        // updateDoorHud(false);
      } else if (ch == '!') {
        torches.emplace_back(x, y); // Add torch at this position
      } else if (ch == '#') {
        springs.emplace_back(x, y); // add spring cell at this position
      } else if (ch == '*') {       // Obstacle
        // Check if an obstacle part is already here to group them
        bool alreadyExists = false;
        for (const auto &obs : obstacles) {
          if (obs.contains(x, y)) {
            alreadyExists = true;
            break;
          }
        }
        if (!alreadyExists) {
          obstacles.emplace_back(x, y, theScreen);
        }
      }
    }
  }
}

void game::handleStepOnObjects(player &pl) {
  int x = pl.getX(); // Player current x
  int y = pl.getY(); // Player current y

  // --- Handle switches ---
  for (size_t i = 0; i < switches.size(); ++i) {
    if (switches[i].getX() == x && switches[i].getY() == y) {

      // Toggle switch state and update display
      switches[i].toggle(theScreen);
      switchOn = switches[i].isOn();
      drawHUD();
      // For room 2: switch that controls door '1'
      if (switches[i].getType() == SwitchType::DOOR && currentRoom == 1) {

        bool doorOpen = false; // Final decision if door is open

        for (auto &d : doors) {
          if (d.getSymbol() == '1' || d.getSymbol() == '3') { // Find door '1'
            bool enoughKeys = d.isOpen(); // Check keys logic
            bool switchOn = switches[i].isOn();
            doorOpen = (enoughKeys && switchOn); // Both conditions must be true
            drawHUD();
            break;
          }
        }
      }

      // Apply wall effect for room 0
      if (switches[i].getType() == SwitchType::WALL && currentRoom == 0) {
        update_Internal_Wall_By_Switch(switches[i]);
      }
      break; // Only one switch per tile
    }
  }

  // --- Handle riddles ---
  for (size_t i = 0; i < riddles.size(); ++i) {
    if (riddles[i].getX() == x && riddles[i].getY() == y) {

      bool solved = riddles[i].ask(); // Show riddle and get answer

      if (solved) {
        setScore(score + 50); // Increase score for correct answer
        std::cout << "Correct answer!" << std::endl;
        std::cout << "you get 50 points! Your current score is: " << getScore()
                  << std::endl;
        Sleep(2500);
        // Correct answer: remove riddle mark from screen and vector
        theScreen.setChar(y, x, ' ');
        riddles.erase(riddles.begin() + i);
      } else {
        setScore(score - 30); // Decrease score for wrong answer
        std::cout << "Wrong answer! Returning to start position." << std::endl;
        std::cout << "you lose 30 points! Your current score is: " << getScore()
                  << std::endl;
        Sleep(3000);
        // Wrong answer: reset player to starting position in this room
        pl.setPosition(pl.get_startpointX(), pl.get_startpointY());
      }
      theScreen.draw(); // Redraw room after change
      drawHUD();
    }
  }

  // --- Handle doors ---
  for (size_t i = 0; i < doors.size(); ++i) {
    if (doors[i].getX() == x && doors[i].getY() == y) {

      // If player holds a key (represented as 'k'), give it to the door
      if (pl.iscarrying_item() && pl.getCarryItem() == 'k') {
        pl.useKey();       // Remove key from player
        doors[i].addKey(); // Increase door key counter
      }
      bool canopen =
          doors[i].isOpen(); // Door open according to its internal logic
      bool hasSwitchPermission = false;

      for (const auto &sw : switches) {
        if (currentRoom == 1 || currentRoom == 2) {
          if (sw.getType() == SwitchType::DOOR && sw.isOn()) {
            hasSwitchPermission = true; // Switch allows opening
            drawHUD();
            break;
          }
          canopen = canopen && hasSwitchPermission; // Need both: keys + switch
        }
      }

      if (canopen) {
        openedDoor = true;
        pl.deactivate();      // Player finished this room
        playerPassedDoor(pl); // Handle room exit logic
        theScreen.draw();     // Redraw room after player exit
        drawHUD();
      }

      // Door remains on map and vector; just stop further checks
      return;
    }
  }

  // --- Handle picking up items (keys, bombs, torches) ---
  // --- Handle picking up items (keys, bombs, torches) ---
  char before = theScreen.board[y][x]; // What was on this tile
  if (pl.pickupIfPossible()) { // Try to pick up (or interact if hand full)
    if (before == 'k') {       // Remove key from keys vector
      for (size_t i = 0; i < keys.size(); ++i) {
        if (keys[i].getX() == x && keys[i].getY() == y) {
          keys.erase(keys.begin() + i);
          break;
        }
      }
    } else if (before == '@') { // Remove bomb item from bombItem vector
      for (size_t i = 0; i < bombItem.size(); ++i) {
        if (bombItem[i].getX() == x && bombItem[i].getY() == y) {
          bombItem.erase(bombItem.begin() + i);
          break;
        }
      }
    } else if (before == '!') { // Remove torch item from torch vector
      for (size_t i = 0; i < torches.size(); ++i) {
        if (torches[i].getX() == x && torches[i].getY() == y) {
          torches.erase(torches.begin() + i);
          break;
        }
      }
    }
  }
  activateSpringIfNeeded(pl);
}
void game::goToNextRoom() {
  if (getTimeGame() < TIME_PER_GAME) {
    setScore(score + 200); // Bonus for finishing room quickly
    cls();
    std::cout << "Room completed quickly! Bonus 200 points! Current score: "
              << getScore() << std::endl;
    Sleep(2500);
  } else {
    setScore(score + 50); // Standard room completion score
    cls();
    std::cout << "Room completed! You get 50 points! Current score: "
              << getScore() << std::endl;
    Sleep(2500);
  }
  if (p1.getLife() == 5 && p2.getLife() == 5) {
    bool Full_Life;
    setScore(score + 500);
    cls();
    std::cout << "you finish the room with full life! Bonus 500 points! "
                 "Current score: "
              << getScore() << std::endl;
    Sleep(2500);
  }
  ++currentRoom; // Move to next room index

  // Check if we reached the end room or beyond
  if (currentRoom >= (int)allRooms.size() - 1) {
    theScreen.setHudInfo(0, 21, false);
    // Load the last room (end screen) from files
    if (currentRoom < (int)allRooms.size()) {
      theScreen.copyFrom(allRooms[currentRoom]);
    }
    theScreen.draw();
    gotoxy(38, 22);
    std::cout << getScore() << std::endl;
    Sleep(100000);
    p1.deactivate(); // Deactivate player 1
    p2.deactivate(); // Deactivate player 2
    return;
  }

  // Load the next room from the vector (read from external files)
  theScreen.copyFrom(allRooms[currentRoom]);
  p1.getIsActiveback(); // Reactivate player 1
  p1.setCarryItem(' ');
  p2.getIsActiveback(); // Reactivate player 2
  p2.setCarryItem(' ');
  keys.clear(); // Clear all old objects
  doors.clear();
  bombItem.clear();
  switches.clear();
  obstacles.clear();      // clear all old objects
  initObjectsFromBoard(); // Scan new board for objects

  // Reset player positions for new room
  if (currentRoom == 1 && getHudY() == 0) {
    setposition_player1(2, 7);
    p1.setStartPosition(2, 7); // New starting position for player 1
    setposition_player2(77, 4);
    p2.setStartPosition(77, 4); // New starting position for player 2
  } else if (currentRoom == 1 && getHudY() == 22) {
    setposition_player1(2, 3);
    p1.setStartPosition(2, 3); // New starting position for player 1
    setposition_player2(77, 1);
    p2.setStartPosition(77, 1); // New starting position for player 2
  } else if (currentRoom == 2 && getHudY() == 0) {
    setposition_player1(34, 15);
    p1.setStartPosition(34, 15); // New starting position for player 1
    setposition_player2(34, 16);
    p2.setStartPosition(34, 16); // New starting position for player 2
  } else if (currentRoom == 2 && getHudY() == 22) {
    setposition_player1(34, 12);
    p1.setStartPosition(34, 12); // New starting position for player 1
    setposition_player2(34, 13);
    p2.setStartPosition(34, 13); // New starting position for player 2
  }
  theScreen.draw();   // Draw whole new room
  p1.draw('$');       // Draw player 1 character
  p2.draw('&');       // Draw player 2 character
  setTimeGame(0);     // Reset game time for new room
  openedDoor = false; // Reset door opened flag
  switchOn = false;   // Reset switch state
  drawHUD();
  p1.updateHUD();
  p2.updateHUD();
}

int game::pause_menu() {
  cls(); // Clear screen and show pause menu
  std::cout << "============ PAUSED ============" << std::endl;
  std::cout << "      ESC - continue game       " << std::endl;
  std::cout << "       H  - return to main menu " << std::endl;
  std::cout << "       I - view instructions    " << std::endl;
  std::cout << "================================" << std::endl;

  while (true) {
    int ch = _getch(); // Wait for user choice
    if (ch == 27) {    // ESC -> continue game
      return 0;
    } else if (ch == 'h' || ch == 'H') { // h/H -> go back to main menu
      return 1;
    } else if (ch == 'i' || ch == 'I') { // i/I -> show instructions
      cls();
      std::cout << "=============================== Game Instructions "
                   "=============================="
                << std::endl;
      std::cout << "|                                                          "
                   "                    |"
                << std::endl;
      std::cout << "|1.There are two players participating in the game world.  "
                   "                    |"
                << std::endl;
      std::cout << "|2.The goal of each player is to reach the end of the "
                   "level and solve all      |"
                << std::endl;
      std::cout << "|  challenges.                                             "
                   "                    |"
                << std::endl;
      std::cout << "|3.Players can move using the following keys:              "
                   "                    |"
                << std::endl;
      std::cout << "|     Player 1: W (Up), A (Left), S (Stay), D (Right), X "
                   "(Down), E (Dispose)   |"
                << std::endl;
      std::cout << "|     Player 2: I (Up), J (Left), K (Stay), L (Right), M "
                   "(Down), O (Dispose)   |"
                << std::endl;
      std::cout << "|4.You will encounter obstacles, doors, keys, "
                   "springs,bombs,and other game     |"
                << std::endl;
      std::cout << "|  elements.                                               "
                   "                    |"
                << std::endl;
      std::cout << "|5.Collaboration is required to overcome obstacles and "
                   "open new paths.         |"
                << std::endl;
      std::cout << "|6.Good luck!                                              "
                   "                    |"
                << std::endl;
      std::cout << "|                                                          "
                   "                    |"
                << std::endl;
      std::cout << "| *for back press b*                                       "
                   "                    |"
                << std::endl;
      std::cout << "==========================================================="
                   "====================="
                << std::endl;

      char press = 'b'; // Wait until user presses 'b'
      while (press != _getch()) {
      };
      cls(); // Redraw pause menu after returning
      std::cout << "============ PAUSED ============" << std::endl;
      std::cout << "      ESC - continue game       " << std::endl;
      std::cout << "       H  - return to main menu " << std::endl;
      std::cout << "       I - view instructions    " << std::endl;
      std::cout << "================================" << std::endl;
    }
  }
}

// perplexity AI
bool game::isPlayerAt(int x, int y, const player *ignore) const {
  const player *other = nullptr; // Pointer to the other player

  if (ignore == &p1)
    other = &p2;
  else if (ignore == &p2)
    other = &p1;
  else
    return false; // ignore is not p1 or p2

  return other->getIsActive() && // Other player must be active
         other->getX() == x &&   // Same x
         other->getY() == y;     // Same y
}

bool game::isLastActivePlayer(const player &pl) const {
  int activeCount = 0; // Count how many players are active
  if (p1.getIsActive())
    ++activeCount;
  if (p2.getIsActive())
    ++activeCount;

  return (activeCount == 1) &&
         pl.getIsActive(); // True if only this player is active
}

void game::playerPassedDoor(player &pl) {
  // Hide player from current position on screen
  pl.draw(' ');

  ++playersExitedThisRoom; // Increment counter of players who left

  // If first player exited, keep room; play continues with remaining player
  if (playersExitedThisRoom == 1) {
    return;
  }

  // If second player also exited, load next room
  if (playersExitedThisRoom == 2) {
    goToNextRoom();
    playersExitedThisRoom = 0; // Reset counter for the new room
  }
}

void game::explodeAt(int x, int y) {
  // First handle visual and board effects
  theScreen.explodeAt(x, y, theScreen.getHudY());

  // Then remove riddles within distance 3 from explosion center
  for (int dy = -3; dy <= 3; ++dy) {
    for (int dx = -3; dx <= 3; ++dx) {
      int nx = x + dx;
      int ny = y + dy;

      if (nx < 0 || nx > Screen::MAX_X || ny < 0 || ny > Screen::MAX_Y)
        continue; // Skip out-of-bounds cells

      for (size_t i = 0; i < riddles.size(); ++i) {
        if (riddles[i].getX() == nx && riddles[i].getY() == ny) {
          riddles.erase(riddles.begin() + i); // Remove riddle in blast radius
          break;
        }
      }
      for (size_t i = 0; i < doors.size(); ++i) {
        if (doors[i].getX() == nx && doors[i].getY() == ny) {
          doors.erase(doors.begin() + i); // Remove door in blast radius
          break;
        }
      }

      for (size_t i = 0; i < obstacles.size(); ++i) {
        if (obstacles[i].contains(nx, ny)) {
          obstacles.erase(obstacles.begin() + i);
          break;
        }
      }
    }
  }
  const int explosionRadius = 3;
  // For player 1
  int dx1 = p1.getX() - x;
  int dy1 = p1.getY() - y;
  int life_p1 = p1.getLife();
  if (abs(dx1) + abs(dy1) <= explosionRadius) {
    p1.setLife(life_p1 - 1);
    p1.updateHUD();
    life_p1 = p1.getLife();
    if (life_p1 <= 0)
      p1.deactivate();
  }

  // For player 2
  int dx2 = p2.getX() - x;
  int dy2 = p2.getY() - y;
  int life_p2 = p2.getLife();
  if (abs(dx2) + abs(dy2) <= explosionRadius) {
    p2.setLife(life_p2 - 1);
    p2.updateHUD();
    life_p2 = p2.getLife();
    if (life_p2 <= 0)
      p2.deactivate();
  }
}

void game::update_Internal_Wall_By_Switch(const Switch &sw) {
  int y = 15;            // Fixed row of internal wall
  const int xStart = 29; // Start x of wall segment
  const int xEnd = 32;   // End x of wall segment

  if (currentRoom != 0)
    return; // Safety: only in room 0

  for (size_t i = 0; i < doors.size(); ++i) {
    if (doors[i].getSymbol() == '2' && theScreen.getHudY() == 0) {
      y = doors[i].getY() - 2;
      break;
    }
    // cls();
    // std::cout << "Switching wall at row " << y << std::endl;
    // Sleep(1000);
  }
  if (sw.isOn()) {
    // ON -> remove wall (replace with spaces)
    for (int x = xStart; x <= xEnd; ++x) {
      theScreen.setChar(y, x, ' ');
      gotoxy(x, y);
      std::cout << ' ' << std::flush;
    }
  } else {
    // OFF -> restore wall (character 'W')
    for (int x = xStart; x <= xEnd; ++x) {
      theScreen.setChar(y, x, 'W');
      theScreen.drawChar(x, y, 'W', Color::LIGHT_CYAN);
    }
  }
}

player *game::getOtherPlayer(const player *pl) {
  if (pl == &p1)
    return &p2;
  if (pl == &p2)
    return &p1;
  return nullptr;
}

int game::countSpringCompressed(const player &pl) const {
  Direction d = pl.getPoint().getDir();
  int dx = d.dx();
  int dy = d.dy();

  if (dx == 0 && dy == 0)
    return 0;

  int x = pl.getX();
  int y = pl.getY();

  int count = 1;

  while (true) {
    x -= dx;
    y -= dy;

    if (x < 0 || x >= Screen::MAX_X || y < 0 || y >= Screen::MAX_Y)
      break;

    char ch = theScreen.board[y][x];

    if (ch == '#') {
      ++count;
    } else {
      break;
    }
  }

  return count;
}

void game::activateSpringIfNeeded(player &pl) {
  if (pl.isUnderSpringEffect())
    return;

  int x = pl.getX();
  int y = pl.getY();

  // 1. must stand on spring cell
  if (theScreen.board[y][x] != '#')
    return;

  Direction inDir = pl.getPoint().getDir();
  int dx = inDir.dx();
  int dy = inDir.dy();

  if (dx == 0 && dy == 0)
    return; // not moving into spring

  int nextX = x + dx;
  int nextY = y + dy;

  // 2. if next cell is also '#', we are still compressing -> do nothing yet
  if (nextX >= 0 && nextX <= Screen::MAX_X && nextY >= 0 &&
      nextY <= Screen::MAX_Y && theScreen.board[nextY][nextX] == '#') {
    return;
  }
  if (theScreen.board[nextY][nextX] == 'W') {
    int k = countSpringCompressed(
        pl); // Check how many spring cells are behind the player
    if (k <= 0)
      return;

    // release direction = opposite to compression
    int outDx = -dx;
    int outDy = -dy;
    Direction outDir(outDx, outDy);

    int speed = k;
    int ticks = k * k;

    pl.setSpringEffect(speed, ticks, outDir);
    pl.setDirection(outDir);
  }
}

//perplexity AI
bool game::tryPushObstacle(point &target, Direction dir) {
  // Try to find if an obstacle is at the target position
  Obstacle *found = nullptr;
  for (auto &obs : obstacles) {
    if (obs.contains(target.getX(), target.getY())) {
      found = &obs;
      break;
    }
  }
  if (!found)
    return false;

  Obstacle &obs = *found;
  int dx = dir.dx();
  int dy = dir.dy();

  int totalForce = 0;

  // Calculate total force: how many players are pushing?
  auto contributes = [&](player &pl) -> int {
    if (!pl.getIsActive())
      return 0;

    // Check if player is moving in the push direction
    if (pl.getPoint().getDir().dx() != dx || pl.getPoint().getDir().dy() != dy)
      return 0;

    // Check "front" cell (cell in front of player)
    int fx = pl.getX() + dx;
    int fy = pl.getY() + dy;

    // If front cell is not part of this obstacle, player doesn't push it
    if (!obs.contains(fx, fy))
      return 0;

    // Return push force (spring effect increases force)
    return pl.isUnderSpringEffect() ? pl.getSpringSpeed() : 1;
  };

  totalForce += contributes(p1);
  totalForce += contributes(p2);

  // If there is any force
  if (totalForce <= 0)
    return false;

  // If total force is enough and obstacle can be pushed
  if (totalForce >= obs.getSize() && obs.canPush(dir, theScreen)) {
    obs.push(dir, theScreen);
    mergeObstaclesOnBoard();
    return true;
  }

  return false;
}

// perplexity AI
void game::mergeObstaclesOnBoard() {
  // Re-scan the board to merge adjacent obstacle cells
  obstacles.clear();

  // Keep track of visited cells to form clusters
  bool visited[Screen::MAX_Y + 1][Screen::MAX_X + 1] = {false};

  for (int y = 0; y <= Screen::MAX_Y; ++y) {
    for (int x = 0; x <= Screen::MAX_X; ++x) {
      if (theScreen.board[y][x] == '*' && !visited[y][x]) {
        // BFS to find all connected parts
        std::vector<point> cluster;
        std::queue<std::pair<int, int>> q;
        q.push({x, y});
        visited[y][x] = true;

        while (!q.empty()) {
          auto [cx, cy] = q.front();
          q.pop();
          cluster.emplace_back(cx, cy, Direction::directions[Direction::STAY],
                               '*');

          const int dx[4] = {1, -1, 0, 0};
          const int dy[4] = {0, 0, 1, -1};

          for (int k = 0; k < 4; ++k) {
            int nx = cx + dx[k];
            int ny = cy + dy[k];
            if (nx < 0 || nx > Screen::MAX_X || ny < 0 || ny > Screen::MAX_Y)
              continue;
            if (theScreen.board[ny][nx] == '*' && !visited[ny][nx]) {
              visited[ny][nx] = true;
              q.push({nx, ny});
            }
          }
        }

        // Store cluster into a new Obstacle object
        Obstacle newObs(0, 0, theScreen); // Create temporary obstacle
        newObs.getCells().clear();
        newObs.setSize(0);

        for (auto &p : cluster) {
          newObs.getCells().push_back(p);
        }
        newObs.setSize((int)cluster.size());

        obstacles.push_back(newObs);
      }
    }
  }
}

bool game::isHudArea(int x, int y) const {
  if (!theScreen.isHudActive())
    return false;
  int hX = theScreen.getHudX();
  int hY = theScreen.getHudY();
  return (x >= hX && x < hX + 67 && // 20 columns
          y >= hY && y < hY + 3);   // 3 rows
}

bool game::findLegendPosition() {
  Screen &currentScreen = getCurrentRoomScreen();
  for (int y = 0; y <= Screen::MAX_Y; ++y) {
    for (int x = 0; x <= Screen::MAX_X; ++x) {
      if (currentScreen.board[y][x] == 'L') {
        currentScreen.setHudInfo(x, y, true);
        return true;
      }
    }
  }
  currentScreen.setHudInfo(0, 0, false);
  return false; // No L found
}

//perplexity AI
bool game::loadSingleScreen(const std::string &filename, int roomIndex) {
  std::ifstream in(filename);
  if (!in) {
    return false; // file not found / cannot open
  }
  Screen room; // local screen to fill

  std::string line;
  for (int y = 0; y <= Screen::MAX_Y; ++y) {
    if (!std::getline(in, line)) {
      line = ""; // Use blank line if file ends early
    }

    // Pad / trim to exactly MAX_X+1 characters
    if ((int)line.size() < Screen::MAX_X)
      line.append(Screen::MAX_X - line.size(), ' ');
    else if ((int)line.size() > Screen::MAX_X)
      line = line.substr(0, Screen::MAX_X);

    for (int x = 0; x <= Screen::MAX_X; ++x) {
      char ch = line[x];

      if (ch == 'L') { // Legend position
        room.setHudInfo(x, y, true);
        ch = ' ';
      }

      if (ch == 'D') { // Dark area
        if (roomIndex == 0) {
          const int DARK_WIDTH = 10;
          const int DARK_HEIGHT = 10;
          room.markDarkRect(x, y, DARK_WIDTH, DARK_HEIGHT);
          ch = ' ';
        } else if (roomIndex == 2) {
          const int DARK_WIDTH = 15;
          const int DARK_HEIGHT = 7;
          room.markDarkRect(x, y, DARK_WIDTH, DARK_HEIGHT);
          ch = ' ';
        }
      }

      room.board[y][x] = ch;
    }
  }

  if ((int)allRooms.size() <= roomIndex)
    allRooms.resize(roomIndex + 1);

  allRooms[roomIndex] = room;
  return true;
}

bool game::loadScreensFromFiles(std::string &errorMsg) {
  allRooms.clear();

  const int MAX_ROOMS = 4;
  int loadedCount = 0;

  for (int i = 1; i <= MAX_ROOMS; ++i) {
    std::string filename = "adv-world0" + std::to_string(i) + ".screen";

    if (loadSingleScreen(filename, i - 1)) {
      loadedCount++;
    } else {
      errorMsg = "CRITICAL ERROR: Failed to load screen file: " + filename +
                 "\nMake sure the file exists and has the correct format (25 "
                 "rows of 80 characters).";
      return false; // Stop at first missing required file
    }
  }

  return (loadedCount == MAX_ROOMS);
}

void game::drawHUD() const {
  if (!theScreen.isHudActive())
    return;

  int hX = theScreen.getHudX();
  int hY = theScreen.getHudY();
  const int maxWidth = 62;

  {
    gotoxy(hX, hY);
    std::string line = "P1($) carry item:    life: ";
    if ((int)line.size() > maxWidth)
      line = line.substr(0, maxWidth);
    std::cout << line << std::flush;
  }

  //  1: P2 item + HP
  {
    gotoxy(hX, hY + 1);
    std::string line = "P2(&) carry item:    life: ";
    if ((int)line.size() > maxWidth)
      line = line.substr(0, maxWidth);
    std::cout << line << std::flush;
  }

  //  2: Door/Switch state
  {
    gotoxy(hX, hY + 2);

    std::string line = "Door open? : ";
    line += (openedDoor ? 'Y' : 'N');
    line += " || Switch open? : ";
    line += (switchOn ? 'Y' : 'N');
    line += " || Score: " + std::to_string(getScore());
    line += " || Time left: ";
    if ((int)line.size() > maxWidth)
      line = line.substr(0, maxWidth);
    std::cout << line << std::flush;
  }
}

//perplexity AI
bool game::loadRiddlesFromFile(const std::string &filename) {
  std::ifstream in(filename);
  if (!in) {
    return false;
  }

  all_riddles.clear();
  std::string line;
  RiddleData currentRiddle;
  int optionIndex = 0;
  bool inRiddle = false;

  while (std::getline(in, line)) {
    if (line.empty())
      continue;

    // Remove CR if present (Windows/Unix line ending diffs)
    if (!line.empty() && line.back() == '\r')
      line.pop_back();

    if (line == "[RIDDLE]") {
      if (inRiddle) {
        // Save previous riddle
        all_riddles.push_back(currentRiddle);
      }
      // Reset for new riddle
      currentRiddle = RiddleData();
      currentRiddle.correctIndex = 0;
      optionIndex = 0;
      inRiddle = true;
    } else if (inRiddle) {
      if (line[0] == '*') {
        // It's an option
        if (optionIndex < 4) {
          currentRiddle.options[optionIndex] = line.substr(1);
          optionIndex++;
        }
      } else if (line.rfind("Correct:", 0) == 0) { // Starts with "Correct:"
        int val = std::stoi(line.substr(8));
        currentRiddle.correctIndex = val - 1; // Convert 1-based to 0-based
      } else {
        // It's part of the question
        if (!currentRiddle.question.empty()) {
          currentRiddle.question += "\n";
        }
        currentRiddle.question += line;
      }
    }
  }
  // Save last riddle
  if (inRiddle) {
    all_riddles.push_back(currentRiddle);
  }

  return !all_riddles.empty();
}
