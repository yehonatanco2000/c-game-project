#pragma once
#include "Bomb.h"
#include "Doors.h"
#include "Menu.h"
#include "Obstacle.h"
#include "Riddle.h"
#include "Screen.h"
#include "Spring.h"
#include "Switch.h"
#include "Torch.h"
#include "keys.h"
#include "player.h"
#include <iostream>
#include <vector>

struct ActiveBomb {
  int x, y;   // Bomb position on the board
  int timer;  // How many game cycles left before explosion
  bool alive; // True if bomb has not exploded yet
};
constexpr int TIME_PER_GAME = 100; // Total time for the game in seconds
constexpr int GAME_CLOCK_TICKS_PER_SECOND = 10;

class game {
  Screen theScreen;              // The game screen (map and drawing)
  player p1;                     // First player
  player p2;                     // Second player
  std::vector<ActiveBomb> bombs; // List of active bombs counting down
  std::vector<keys> keys;        // All key items in the current room
  std::vector<Doors> doors;      // All doors in the current room
  std::vector<Bomb> bombItem;    // Bomb items lying on the floor (collectable)
  std::vector<Riddle> riddles;   // All riddles in the current room
  std::vector<Switch> switches;  // All switches in the current room
  std::vector<Torch> torches;    // All torches in the current room
  std::vector<Spring> springs;   // All springs in the current room
  std::vector<Obstacle> obstacles;     // All obstacles in the current room
  std::vector<Screen> allRooms;        // Loaded rooms from files
  std::vector<RiddleData> all_riddles; // Loaded riddles from text file
  bool openedDoor = false;             // Is the door currently open?
  bool switchOn = false;               // Is the switch currently ON?
  int currentRoom = 0;                 // Index of the current room
  int playersExitedThisRoom = 0; // How many players already exited this room
  int doorTargetRoom = 1;        // Room index to go to when passing the door
  int nextRiddleIndex = 0;       // Index of the next riddle to activate/check
  bool useFileRooms = false;
  bool loadSuccess = true;
  std::string fatalError;
  int score = 0;
  int TimeGame = 0;
  friend Menu; // Allow Menu class to access private members
public:
  game()                        // Game constructor
      : theScreen(getScreen()), // Use shared Screen instance
        p1(point(3, 9, {0, 0}, '$'), "dxaws", theScreen, ' '), // Init player 1
        p2(point(68, 9, {0, 0}, '&'), "lmjik", theScreen, ' ') // Init player 2
  {
    p1.setGamePtr(this); // Give player 1 pointer back to game
    p2.setGamePtr(this); // Give player 2 pointer back to game

    useFileRooms = loadScreensFromFiles(fatalError);
    if (useFileRooms) {
      currentRoom = 0;
      theScreen.copyFrom(allRooms[currentRoom]);
    } else {
      loadSuccess = false;
      return;
    }

    if (!loadRiddlesFromFile("riddles.txt")) {
      loadSuccess = false;
      fatalError = "CRITICAL ERROR: Failed to load 'riddles.txt' or file is "
                   "empty.\nPlease verify that the riddle file is present and "
                   "correctly formatted.";
      return;
    }

    initObjectsFromBoard(); // Scan board and create keys, doors, etc.
  }
  void start_game(); // Main game loop entry point
  void addBomb(int x, int y) {
    bombs.push_back(
        {x, y, 5, true}); // Add new active bomb at (x,y) with 5 cycles
  }
  bool
  isPlayerAt(int x, int y,
             const player *ignore) const; // Check if any player is at (x,y)
  void handleStepOnObjects(player &pl);   // Handle player stepping on items
  void goToNextRoom();                    // Move game to the next room
  bool isLastActivePlayer(
      const player &pl) const;       // Check if this is the last active player
  void playerPassedDoor(player &pl); // Logic when player passes a door
  void explodeAt(int x, int y);      // Trigger explosion at (x,y)
  void update_Internal_Wall_By_Switch(
      const Switch &sw); // Update walls affected by a switch
  void setposition_player1(int x, int y) {
    p1.setPosition(x, y); // Set position of player 1
  }
  void setposition_player2(int x, int y) {
    p2.setPosition(x, y); // Set position of player 2
  }
  player *getOtherPlayer(const player *pl);
  bool tryPushObstacle(point &target, Direction dir);
  void mergeObstaclesOnBoard();
  int getHudX() const { return theScreen.getHudX(); }
  int getHudY() const { return theScreen.getHudY(); }
  bool isHudZone(int x, int y) const {
    return theScreen.isHudActive() && theScreen.getHudY() != -1 &&
           isHudArea(x, y);
  }
  Screen &getCurrentRoomScreen() {
    return useFileRooms && currentRoom < allRooms.size() ? allRooms[currentRoom]
                                                         : theScreen;
  }
  void drawHUD() const; // draw HUD (legend) starting from L position
  bool isHudArea(int x, int y) const; // Check if (x,y) is in HUD zone
  int getScore() const { return score; }
  void setScore(int s) { score = s; }
  int getTimeGame() const { return TimeGame; }
  void setTimeGame(int t) { TimeGame = t; }

private:
  void initObjectsFromBoard(); // Read screen board and create all objects
  int pause_menu();            // Show pause menu and return user choice
  int countSpringCompressed(const player &pl) const;
  void activateSpringIfNeeded(player &pl);

  bool loadScreensFromFiles(std::string &errorMsg);
  bool loadSingleScreen(const std::string &filename, int roomIndex);
  bool findLegendPosition(); // Find first L position
  bool loadRiddlesFromFile(
      const std::string &filename); // Load riddles from text file
};
